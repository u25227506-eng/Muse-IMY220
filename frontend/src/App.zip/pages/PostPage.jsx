import {useState, useEffect} from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navigation from "../components/Navigation";
import Post from "../components/Post";
import EditPost from "../components/EditPost";


function PostPage(){
    const {id} = useParams();
    const navigate = useNavigate();
    const currentUser = JSON.parse(localStorage.getItem("museUser"));
    const [post, setPost] = useState(null);
    const [editing, setEditing] = useState(false);
    const [commentText, setCommentText] = useState("");
    const [albums, setAlbums] = useState([]); 

    function loadPost(){
        fetch(`http://localhost:5000/api/posts/${id}`)
            .then(res => res.json())
            .then(data => setPost(data));
    }

    useEffect(() => {loadPost(); }, [id]);
    useEffect(() => {
    if (currentUser) {
        fetch(`http://localhost:5000/api/users/${currentUser._id}/albums`)
            .then(res => res.json())
            .then(data => setAlbums(data));
    }
}, [currentUser]);

    async function handleAddComment(e){
        e.preventDefault();
        if(!commentText.trim()) return;
        await fetch(`http://localhost:5000/api/posts/${id}/comments`, {
            method: "POST",
            headers: {"Content-type": "application/json"},
            body: JSON.stringify({userId: currentUser._id, username: currentUser.username, text: commentText}),
        });
        setCommentText("");
        loadPost();
    }

    async function handleDelete(){
        await fetch(`http://localhost:5000/api/posts/${id}`, {method: "DELETE"});
        navigate("/home");
    }

    async function handleReport(){
        await fetch(`http://localhost:5000/api/posts/${id}/report`, {
            method: "POST",
        });
        alert("Post reported");
    }


    if (!post){
        return (
            <div> 
                <Navigation />
                <p>Loading...</p>
            </div>
        );
    }

    


    const isOwner = currentUser && currentUser._id === post.userId;

    return (
        <div>
            <Navigation />
            <Post post={post} />

            {isOwner && !editing && (
                <div> 
                    <button onClick={() => setEditing(true)}>Edit Post</button>
                    <button onClick={handleDelete}>Delete Post</button>
                </div>
            )}  

            {isOwner && editing && (
                <EditPost post={post} onSave={() => {setEditing(false); loadPost(); }} />
            )}


            {isOwner && albums.length > 0 && (
                <select onChange={(e) => {
                    if (e.target.value) {
                        fetch(`http://localhost:5000/api/albums/${e.target.value}/posts`, {
                            method: "POST",
                            headers: {"Content-type": "application/json"},
                            body: JSON.stringify({ postId: post._id }),
                        });
                    }
                }}>
                    <option value="">Add to album...</option>
                    {albums.map(a => <option key={a._id} value={a._id}>{a.name}</option>)}
                </select>
            )}

            <form onSubmit={handleAddComment}>
                <input  
                    type="text"
                    placeholder="Add a comment..."
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                />
                <button type="submit">Comment</button>
            </form>

            {!isOwner && (
                <button onClick={handleReport}>Report Post</button>
            )}

        </div>
    );
}

export default PostPage;