import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navigation from "../components/Navigation";
import PostPreview from "../components/PostPreview";

function AlbumPage() {
    const { id } = useParams();
    const navigate = useNavigate();
    const currentUser = JSON.parse(localStorage.getItem("museUser"));
    const [album, setAlbum] = useState(null);
    const [editing, setEditing] = useState(false);
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");

    function loadAlbum() {
        fetch(`http://localhost:5000/api/albums/${id}`)
            .then(res => res.json())
            .then(data => {
                setAlbum(data);
                setName(data.name);
                setDescription(data.description);
            });
    }

    useEffect(() => { loadAlbum(); }, [id]);

    const isOwner = currentUser && album && currentUser._id === album.userId;

    async function handleSaveEdit(e) {
        e.preventDefault();
        await fetch(`http://localhost:5000/api/albums/${id}`, {
            method: "PUT",
            headers: { "Content-type": "application/json" },
            body: JSON.stringify({ name, description, hashtags: album.hashtags }),
        });
        setEditing(false);
        loadAlbum();
    }

    async function handleDelete() {
        await fetch(`http://localhost:5000/api/albums/${id}`, { method: "DELETE" });
        navigate(`/profile/${currentUser._id}`);
    }

    async function handleRemovePost(postId) {
        await fetch(`http://localhost:5000/api/albums/${id}/posts/${postId}`, { method: "DELETE" });
        loadAlbum();
    }

    if (!album) return <div><Navigation /><p>Loading...</p></div>;

    return (
        <div>
            <Navigation />
            {!editing ? (
                <div>
                    <h2>{album.name}</h2>
                    <p>{album.description}</p>
                </div>
            ) : (
                <form onSubmit={handleSaveEdit}>
                    <input value={name} onChange={(e) => setName(e.target.value)} />
                    <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
                    <button type="submit">Save</button>
                </form>
            )}

            {isOwner && !editing && (
                <div>
                    <button onClick={() => setEditing(true)}>Edit Album</button>
                    <button onClick={handleDelete}>Delete Album</button>
                </div>
            )}

            <h4>Posts in this album</h4>
            {album.posts?.map((post) => (
                <div key={post._id}>
                    <PostPreview post={post} />
                    {isOwner && <button onClick={() => handleRemovePost(post._id)}>Remove from album</button>}
                </div>
            ))}
        </div>
    );
}

export default AlbumPage;