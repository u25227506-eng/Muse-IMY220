import {useState, useEffect} from "react";
import {useNavigate} from "react-router-dom";

import Navigation from "../components/Navigation";
import Feed from "../components/Feed";
import SearchInput from "../components/SearchInput";

function Home(){
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("museUser"));
    const [posts, setPosts] = useState([]);
    const [feedType, setFeedType] = useState("local");
    
    useEffect(() => {
        if (!user){
            navigate("/");
            return;
        }
        const url = feedType === "local" 
            ? `http://localhost:5000/api/users/${user._id}/feed`
            : `http://localhost:5000/api/posts`;

        fetch(url)
            .then(res => res.json())
            .then(data => setPosts(data));
    }, [feedType, user, navigate]);

    if (!user){
        return null;
    }

    return (
        <div> 
            <Navigation />
            <SearchInput />
            <button onClick={() => setFeedType("local")}>Local Feed</button>
            <button onClick={() => setFeedType("global")}>Global Feed</button>
            <Feed posts={posts} />
        </div>
    );
}

export default Home;
