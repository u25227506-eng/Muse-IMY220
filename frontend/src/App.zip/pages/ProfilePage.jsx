import {useState, useEffect} from "react";
import { useParams} from "react-router-dom";
import Navigation from "../components/Navigation";
import Profile from "../components/Profile";
import Friend from "../components/Friend";
import CreatePost from "../components/CreatePost";
import EditProfile from "../components/EditProfile";
import Feed from "../components/Feed";
import CreateAlbum from "../components/CreateAlbum";
import AlbumPreview from "../components/AlbumPreview";

function ProfilePage(){
    const {id} = useParams();
    const currentUser = JSON.parse(localStorage.getItem("museUser"));
    const [profileUser, setProfileUser] = useState(null);
    const [posts, setPosts] = useState([]);
    const [editing, setEditing] = useState(false);
    const [albums, setAlbums] = useState([]);

    const isOwnProfile = currentUser && currentUser._id === id;

    useEffect(() => {
        fetch(`http://localhost:5000/api/users/${id}`)
            .then(res => res.json())
            .then(data => setProfileUser(data));

        fetch(`http://localhost:5000/api/users/${id}/posts`)
            .then(res => res.json())
            .then(data => setPosts(data));
        
        fetch(`http://localhost:5000/api/users/${id}/albums`)
            .then(res => res.json())
            .then(data => setAlbums(data));
    }, [id]);


    async function sendFriendRequest(){
        await fetch(`http://localhost:5000/api/users/${id}/friend-request`, {
            method: "POST", 
            headers: {"Content-type": "application/json"},
            body: JSON.stringify({fromUserId: currentUser._id}),
        });
        const res = await fetch(`http://localhost:5000/api/users/${id}`);
        setProfileUser(await res.json());
    }

    async function acceptFriendRequest(friendId){
        await fetch(`http://localhost:5000/api/users/${currentUser._id}/accept-friend`, {
            method: "POST", 
            headers: {"Content-type": "application/json"},
            body: JSON.stringify({friendId}),
        });
        const res = await fetch(`http://localhost:5000/api/users/${id}`);
        setProfileUser(await res.json());
    }

    async function handleUnfriend(){
        await fetch(`http://localhost:5000/api/users/${currentUser._id}/unfriend/${id}`, {
            method: "DELETE",
        });
        const res = await fetch(`http://localhost:5000/api/users/${id}`);
        setProfileUser(await res.json());
    }

    if (!profileUser){
        return (
            <div>
                <Navigation />
                <p>Loading...</p>
            </div>
        );
    }

    const isFriend = profileUser.friends?.some(f => f._id === currentUser?._id);
    const requestPending = profileUser.friendRequests?.some(f => f._id == currentUser?._id);
    const theyRequestedYou = isOwnProfile && profileUser.friendRequests?.length > 0;

    return (
        <div>
            <Navigation />
            <Profile user={profileUser} />

            {isOwnProfile && !editing && <button onClick={() => setEditing(true)}>Edit Profile</button>}
            {isOwnProfile && editing && <EditProfile user={profileUser} onSave={(updated) => {
                setProfileUser(updated); setEditing(false)}} />}

            {!isOwnProfile && !isFriend && !requestPending && (
                <button onClick={sendFriendRequest}>Add Friend</button>
            )}
            {!isOwnProfile && requestPending && <p>Friend request sent</p>}
            {!isOwnProfile && isFriend && (
                <div>
                    <p>Friends</p>
                    <button onClick={handleUnfriend}>Unfriend</button>
                </div>
            )}

            {theyRequestedYou && profileUser.friendRequests.map(req => (
                <div key={req._id}>
                    <p>{req.username} wants to be friends</p>
                    <button onClick={() => acceptFriendRequest(req._id)}>Accept</button>
                </div>
            ))}

            {(isOwnProfile || isFriend) && (
                <div>
                    <h4>Friends</h4>
                    {profileUser.friends?.map((friend) => (
                        <Friend key={friend._id} friend={friend} />
                    ))}
                </div>
            )}

            <Feed posts={posts} />

            <h4>Albums</h4>
            {albums.map((album) => (
                <AlbumPreview key={album._id} album={album} />
            ))}
            {isOwnProfile && (
                <CreateAlbum userId={currentUser._id} onCreated={(newAlbum) => setAlbums([...albums, newAlbum])} />
            )}

            {isOwnProfile && <CreatePost />}
        </div> 
    );
}

export default ProfilePage;
