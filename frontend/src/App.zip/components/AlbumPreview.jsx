import { Link } from "react-router-dom";

function AlbumPreview({ album }) {
    return (
        <div>
            <Link to={`/album/${album._id}`}>{album.name}</Link>
            <p>{album.description}</p>
        </div>
    );
}

export default AlbumPreview;