import {Link} from "react-router-dom";

function PostPreview({post}){
    return (
        <div> 
            <Link to={`/profile/${post.userId}`}>{post.username}</Link>
            <img src={`http://localhost:5000${post.imageUrl}`} alt={post.description} width="200"/>
            <p>{post.description}</p>
            <Link to={`/post/${post._id}`}>View Post</Link>
        </div>
    );
}

export default PostPreview;

