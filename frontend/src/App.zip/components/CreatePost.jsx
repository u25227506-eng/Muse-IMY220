import {useState} from "react";
import {useNavigate} from "react-router-dom";

function CreatePost() {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("museUser"));
    const [description, setDescription] = useState("");
    const [hashtags, setHashtags] = useState("");
    const [imageFile, setImageFile] = useState(null)

    async function handleSubmit(e){
        e.preventDefault();
        if (!imageFile){
            return;
        }

        const formData = new FormData();
        formData.append("image", imageFile);
        formData.append("userId", user._id);
        formData.append("username", user.username);
        formData.append("description", description);
        formData.append("hashtags", hashtags);

        const response = await fetch("http://localhost:5000/api/posts", {
            method: "POST",
            body: formData,
        });
        if (response.ok){
            setDescription("");
            setHashtags("");
            setImageFile(null);
            navigate("/home");
        }
    }

    return (
        <form onSubmit={handleSubmit}>
            <input 
                type="file"
                accept="image/*"
                onChange={(e) => setImageFile(e.target.files[0])}
            />
            <textarea   
                placeholder="write a caption..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
            />
            <input
                type="text"
                placeholder="hashtags (comma separated)"
                value={hashtags}
                onChange={(e) => setHashtags(e.target.value)}
            />

            <button type="submit">Post</button>
        </form>
    );
}

export default CreatePost;