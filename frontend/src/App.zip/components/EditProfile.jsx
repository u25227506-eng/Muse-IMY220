import {useState} from "react";


function EditProfile({user, onSave}) {
    const [bio, setBio] = useState(user.bio);
    const [username, setUsername] = useState(user.username);

    async function handleSubmit(e){
        e.preventDefault();
        const response = await fetch(`http://localhost:5000/api/users/${user._id}`, {
            method: "PUT", 
            headers: {"Content-type": "application/json"},
            body: JSON.stringify({username, bio, avatarUrl: user.avatarUrl}),
        });
        const updated = await response.json();
        onSave(updated);
    }

    return (
        <form onSubmit={handleSubmit}>
            <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
            />
            <textarea
                value={bio}
                onChange={(e) =>setBio(e.target.value)}
            />
            <button type="submit">Save Changes</button>
        </form>
    );
}


export default EditProfile;