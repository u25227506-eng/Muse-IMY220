import Image from "./Image";
import Comments from "./Comments";

function Post({post}){
    return (
        <div>
            <h3>{post.username}</h3>
            <Image src={`http://localhost:5000${post.imageUrl}`} alt={post.description} />
            <p>{post.description}</p>
            <p>{post.hashtags?.join(" ")}</p>
            <Comments comments={post.comments}/>

        </div>
    );
}

export default Post;