import {useState} from "react";

function EditPost({post, onSave}){
    const [description, setDescription] = useState(post.description);
    const [hashtags, setHashtags] = useState(post.hashtags?.join(", "));

    async function handleSubmit(e){
        e.preventDefault();
        await fetch (`http://localhost:5000/api/posts/${post._id}`, {
            method: "PUT", 
            headers: {"Content-type": "application/json"},
            body: JSON.stringify({description, hashtags: hashtags.split(",").map(h => h.trim())}),
        });
        onSave();
    }

    return (
        <form onSubmit={handleSubmit}>
            <textarea   
                value={description}
                onChange={(e) => setDescription(e.target.value)}
            />
            <input 
                type="text"
                value={hashtags}
                onChange={(e) => setHashtags(e.target.value)}
            />

            <button type="submit">Save</button>
        </form>
    );
}

export default EditPost;

