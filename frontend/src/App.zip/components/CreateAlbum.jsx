import { useState } from "react";

function CreateAlbum({ userId, onCreated }) {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [hashtags, setHashtags] = useState("");

    async function handleSubmit(e) {
        e.preventDefault();
        const hashtagArray = hashtags ? hashtags.split(",").map(h => h.trim()) : [];
        const response = await fetch("http://localhost:5000/api/albums", {
            method: "POST",
            headers: { "Content-type": "application/json" },
            body: JSON.stringify({ userId, name, description, hashtags: hashtagArray }),
        });
        const album = await response.json();
        setName("");
        setDescription("");
        setHashtags("");
        onCreated(album);
    }

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                placeholder="album name"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />
            <textarea
                placeholder="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
            />
            <input
                type="text"
                placeholder="hashtags (comma separated)"
                value={hashtags}
                onChange={(e) => setHashtags(e.target.value)}
            />
            <button type="submit">Create Album</button>
        </form>
    );
}

export default CreateAlbum;